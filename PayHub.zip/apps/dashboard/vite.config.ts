import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({plugins:[react()],server:{proxy:{'/api':'http://localhost:3081'}},test:{environment:'jsdom',setupFiles:'./src/test-setup.ts'}});
