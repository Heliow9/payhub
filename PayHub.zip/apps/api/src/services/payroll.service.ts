import type { Pool, PoolConnection, ResultSetHeader, RowDataPacket } from 'mysql2/promise';
import { promisify } from 'node:util';
import { gzip } from 'node:zlib';
import { badRequest, notFound } from '../core/errors.js';
import { maskCpf, sha256 } from '../core/security.js';
import { parseJson } from '../core/json.js';
import type { EmployeeContext, RequestMeta, RequestContext, UserContext } from '../core/types.js';
import { AuditService } from './audit.service.js';
import { buildPayrollPdf } from './pdf.service.js';
import { StorageService } from './storage.service.js';
import { normalizePayrollBatches, type SourceBatch } from './normalizer.service.js';
import { NotificationService } from './notification.service.js';
import { withSignatureEvidenceDisclosure } from './signature-disclosure.js';
import type { NormalizationClaim, NormalizationResult } from './normalization-queue.service.js';
import { createDocumentNumber } from './document-number.js';

const gzipAsync=promisify(gzip);

function isTransientDbLock(error:unknown):boolean{const value=error as {code?:string;errno?:number};return value?.code==='ER_LOCK_DEADLOCK'||value?.errno===1213||value?.code==='ER_LOCK_WAIT_TIMEOUT'||value?.errno===1205;}
const sleep=(ms:number)=>new Promise((resolve)=>setTimeout(resolve,ms));


function sageSnapshotValue(raw:unknown,aliases:string[]):string|null{
  const snapshot=parseJson<Record<string,unknown>>(raw,{});const entries=new Map(Object.entries(snapshot).map(([k,v])=>[k.toLowerCase(),v]));
  for(const alias of aliases){const value=entries.get(alias.toLowerCase());if(value!==undefined&&value!==null&&String(value).trim()!=='')return String(value).trim();}
  return null;
}
const cboAliases=['cbo_atual','cbo2002','cbo','cd_cbo','nr_cbo','codigo_cbo','cbo_funcao','cd_cbo_funcao'];
const legacyPayrollFooter='Documento gerado pelo PayHub a partir dos dados de folha recebidos do Sage.';

function exportFileSafe(value:string):string{return value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^A-Za-z0-9._-]+/g,'_').replace(/^_+|_+$/g,'').slice(0,90)||'HOLERITE';}
export type PayrollExportEntry={payrollId:number;employeeName:string;competence:string;typeLabel:string;status:string;documentKind:'ASSINADO'|'ORIGINAL';sha256:string;filename:string;buffer:Buffer};
type PayrollAdminFilters={employeeId?:number;groupId?:number;year?:number;month?:number;status?:string;type?:number;search?:string};
type PayrollAdminPageFilters=PayrollAdminFilters&{page?:number;pageSize?:number;sort?:string};

export class PayrollService{
  constructor(private pool:Pool,private storage:StorageService,private audit:AuditService,private notifications:NotificationService,private appOrigin='http://localhost'){}

  private async normalizationJob(claim:NormalizationClaim):Promise<RowDataPacket>{
    const [rows]=await this.pool.execute<RowDataPacket[]>(`SELECT j.id,j.company_id companyId,j.payroll_run_id payrollRunId,j.scope_json scopeJson,j.status,j.normalized_at normalizedAt,j.normalization_state normalizationState,j.normalization_owner normalizationOwner,c.sage_company_code companyCode FROM import_jobs j JOIN companies c ON c.id=j.company_id WHERE j.id=? AND j.company_id=? LIMIT 1`,[claim.jobId,claim.companyId]);
    const job=rows[0];
    if(!job||job.status!=='COMPLETED'||job.normalizedAt)throw badRequest('Job de folha não está disponível para normalização.','PAYROLL_JOB_NOT_NORMALIZABLE');
    if(job.normalizationState!=='CLAIMED'||String(job.normalizationOwner??'')!==claim.owner)throw badRequest('Lease de normalização inválido ou expirado.','NORMALIZATION_LEASE_LOST');
    if(job.payrollRunId!=null&&claim.payrollRunId!=null&&Number(job.payrollRunId)!==claim.payrollRunId)throw badRequest('O job está associado a outro processamento.','JOB_COMPANY_MISMATCH');
    return job;
  }

  private async normalizedInput(job:RowDataPacket):Promise<ReturnType<typeof normalizePayrollBatches>>{
    const scope=parseJson<{employeeCodes?:string[]}>(job.scopeJson,{});const target=scope.employeeCodes??[];
    const [batchRows]=await this.pool.execute<RowDataPacket[]>(`SELECT source_table sourceTable,payload_json payload FROM connector_raw_batches WHERE job_id=? AND company_id=? ORDER BY source_table,batch_number`,[job.id,job.companyId]);
    const batches:SourceBatch[]=batchRows.map((b)=>({sourceTable:String(b.sourceTable),rows:parseJson<Array<Record<string,unknown>>>(b.payload,[])}));
    return normalizePayrollBatches(batches,target);
  }

  private payrollPdf(employee:RowDataPacket,p:ReturnType<typeof normalizePayrollBatches>[number],documentNumber:string):Buffer{
    const base=(p.rawReference?.base??{}) as Record<string,unknown>;
    const salaryBase=p.items.find((i)=>i.code==='1'&&i.nature==='EARNING')?.amount??null;
    const fgtsBase=base.vl_base_fgts==null?null:Number(base.vl_base_fgts);
    return buildPayrollPdf({employeeName:String(employee.name),cpfMasked:maskCpf(String(employee.cpf)),sageCode:String(employee.sageCode),competence:`${String(p.month).padStart(2,'0')}/${p.year}`,typeLabel:p.payrollTypeLabel,jobTitle:employee.jobTitle?String(employee.jobTitle):null,admissionDate:employee.admissionDate?String(employee.admissionDate):null,cbo:sageSnapshotValue(employee.sageSnapshotJson,cboAliases),gross:p.gross,deductions:p.deductions,net:p.net,salaryBase,inssBase:base.vl_base_inss==null?null:Number(base.vl_base_inss),fgtsBase,fgtsMonth:fgtsBase==null?null:Math.round(fgtsBase*8)/100,irrfBase:base.vl_base_irrf==null?null:Number(base.vl_base_irrf),irrfBracket:0,items:p.items.map((i)=>({code:i.code,description:i.description,reference:i.reference,amount:i.amount,nature:i.nature})),documentNumber,verificationUrl:`${this.appOrigin}/#/verificar?codigo=${encodeURIComponent(documentNumber)}`});
  }

  private async allocateDocumentNumber(year:number,month:number):Promise<string>{
    for(let attempt=0;attempt<8;attempt++){
      const candidate=createDocumentNumber(year,month);
      const [rows]=await this.pool.execute<RowDataPacket[]>(`SELECT id FROM payrolls WHERE document_number=? LIMIT 1`,[candidate]);
      if(!rows[0])return candidate;
    }
    throw new Error('Não foi possível reservar um número único para o holerite.');
  }

  private async insertPayrollItems(conn:PoolConnection,payrollId:number,items:ReturnType<typeof normalizePayrollBatches>[number]['items']):Promise<void>{
    const chunkSize=200;
    for(let start=0;start<items.length;start+=chunkSize){
      const chunk=items.slice(start,start+chunkSize);
      if(!chunk.length)continue;
      const placeholders=chunk.map(()=>'(?,?,?,?,?,?,?)').join(',');
      const params:unknown[]=[];
      chunk.forEach((item,index)=>params.push(payrollId,item.code,item.description,item.reference,item.amount,item.nature,start+index));
      await conn.query(`INSERT INTO payroll_items (payroll_id,event_code,description,reference_value,amount,nature,sort_order) VALUES ${placeholders}`,params);
    }
  }

  private async originalDocumentIntact(pathValue:unknown,hashValue:unknown):Promise<boolean>{
    const relative=String(pathValue??'');const expected=String(hashValue??'');if(!relative||!expected)return false;
    try{const buffer=await this.storage.read(relative);return sha256(buffer)===expected;}catch{return false;}
  }

  private async employeeForPayroll(companyId:number,sageEmployeeCode:string,jobId:number,payrollRunId:number|null):Promise<RowDataPacket|null>{
    const [employeeRows]=await this.pool.execute<RowDataPacket[]>(`SELECT id,name,cpf,sage_employee_code sageCode,job_title jobTitle,DATE_FORMAT(admission_date,'%Y-%m-%d') admissionDate,sage_snapshot_json sageSnapshotJson FROM employees WHERE company_id=? AND sage_employee_code=? AND status='ACTIVE' LIMIT 1`,[companyId,sageEmployeeCode]);
    const employee=employeeRows[0];if(employee)return employee;
    const [foreignRows]=await this.pool.execute<RowDataPacket[]>(`SELECT id,company_id companyId FROM employees WHERE company_id<>? AND sage_employee_code=? LIMIT 1`,[companyId,sageEmployeeCode]);
    if(foreignRows[0]){
      await this.audit.record({companyId,action:'PAYROLL_NORMALIZATION_FAILED',targetType:'IMPORT_JOB',targetId:jobId,metadata:{jobId,payrollRunId,sageEmployeeCode,reason:'JOB_COMPANY_MISMATCH'}});
      throw badRequest('O job referencia funcionário de outra empresa.','JOB_COMPANY_MISMATCH');
    }
    return null;
  }

  private async preloadEmployees(companyId:number,payrolls:ReturnType<typeof normalizePayrollBatches>):Promise<Map<string,RowDataPacket>>{
    const codes=[...new Set(payrolls.map((p)=>String(p.sageEmployeeCode)).filter(Boolean))];const result=new Map<string,RowDataPacket>();const chunkSize=500;
    for(let start=0;start<codes.length;start+=chunkSize){const chunk=codes.slice(start,start+chunkSize);if(!chunk.length)continue;const placeholders=chunk.map(()=>'?').join(',');const [rows]=await this.pool.execute<RowDataPacket[]>(`SELECT id,name,cpf,sage_employee_code sageCode,job_title jobTitle,DATE_FORMAT(admission_date,'%Y-%m-%d') admissionDate,sage_snapshot_json sageSnapshotJson FROM employees WHERE company_id=? AND status='ACTIVE' AND sage_employee_code IN (${placeholders})`,[companyId,...chunk]);for(const row of rows)result.set(String(row.sageCode),row);}
    return result;
  }

  private async preloadCurrentPayrolls(companyId:number,employees:Map<string,RowDataPacket>,payrolls:ReturnType<typeof normalizePayrollBatches>):Promise<Map<string,RowDataPacket>>{
    const employeeIds=[...new Set([...employees.values()].map((row)=>Number(row.id)).filter((id)=>Number.isFinite(id)&&id>0))];const result=new Map<string,RowDataPacket>();if(!employeeIds.length)return result;
    const years=[...new Set(payrolls.map((p)=>p.year))];const months=[...new Set(payrolls.map((p)=>p.month))];
    const idPlaceholders=employeeIds.map(()=>'?').join(',');const yearPlaceholders=years.map(()=>'?').join(',');const monthPlaceholders=months.map(()=>'?').join(',');
    const [rows]=await this.pool.execute<RowDataPacket[]>(`SELECT p.id,p.employee_id employeeId,p.year,p.month,p.payroll_type payrollType,p.version,p.document_number documentNumber,p.source_hash sourceHash,p.render_hash renderHash,p.status,p.is_current isCurrent,d.original_path originalPath,d.original_sha256 originalSha FROM payrolls p LEFT JOIN payroll_documents d ON d.payroll_id=p.id WHERE p.company_id=? AND p.is_current=1 AND p.employee_id IN (${idPlaceholders}) AND p.year IN (${yearPlaceholders}) AND p.month IN (${monthPlaceholders})`,[companyId,...employeeIds,...years,...months]);
    for(const row of rows)result.set(`${row.employeeId}|${row.year}|${row.month}|${row.payrollType}`,row);return result;
  }

  private async persistNormalizedPayroll(job:RowDataPacket,p:ReturnType<typeof normalizePayrollBatches>[number],employeeOverride?:RowDataPacket|null,currentOverride?:RowDataPacket|null):Promise<'created'|'repaired'|'unchanged'|'skipped'>{
    const companyId=Number(job.companyId);const payrollRunId=job.payrollRunId==null?null:Number(job.payrollRunId);
    const employee=employeeOverride===undefined?await this.employeeForPayroll(companyId,p.sageEmployeeCode,Number(job.id),payrollRunId):employeeOverride;if(!employee)return'skipped';
    let current=currentOverride;
    if(currentOverride===undefined){const [currentRows]=await this.pool.execute<RowDataPacket[]>(`SELECT p.id,p.version,p.document_number documentNumber,p.source_hash sourceHash,p.render_hash renderHash,p.status,p.is_current isCurrent,d.original_path originalPath,d.original_sha256 originalSha FROM payrolls p LEFT JOIN payroll_documents d ON d.payroll_id=p.id WHERE p.company_id=? AND p.employee_id=? AND p.year=? AND p.month=? AND p.payroll_type=? AND p.is_current=1 ORDER BY p.version DESC LIMIT 1`,[companyId,employee.id,p.year,p.month,p.payrollType]);current=currentRows[0]??null;}
    const summary={employeeName:String(employee.name),competence:`${String(p.month).padStart(2,'0')}/${p.year}`,typeLabel:p.payrollTypeLabel,gross:p.gross,deductions:p.deductions,net:p.net,itemCount:p.items.length};

    if(current&&(String(current.renderHash??'')===p.renderHash||String(current.sourceHash)===p.sourceHash)){
      if(String(current.status)==='SIGNED')return'unchanged';
      const intact=await this.originalDocumentIntact(current.originalPath,current.originalSha);
      if(intact&&!['PROCESSING','ERROR'].includes(String(current.status)))return'unchanged';
      const documentNumber=String(current.documentNumber);const pdf=this.payrollPdf(employee,p,documentNumber);const conn=await this.pool.getConnection();
      try{
        await conn.beginTransaction();
        const [lockedRows]=await conn.execute<RowDataPacket[]>(`SELECT id,status,source_hash sourceHash,render_hash renderHash FROM payrolls WHERE id=? AND company_id=? AND is_current=1 FOR UPDATE`,[current.id,companyId]);const locked=lockedRows[0];
        if(!locked)throw new Error(`Holerite #${current.id} deixou de ser a versão atual durante o reparo.`);
        if(String(locked.status)==='SIGNED'){await conn.rollback();return'unchanged';}
        if(String(locked.renderHash??'')!==p.renderHash&&String(locked.sourceHash)!==p.sourceHash)throw new Error(`Holerite #${current.id} mudou durante o reparo.`);
        await conn.execute(`DELETE FROM payroll_items WHERE payroll_id=?`,[current.id]);await this.insertPayrollItems(conn,Number(current.id),p.items);
        await conn.execute(`UPDATE payrolls SET payroll_run_id=COALESCE(payroll_run_id,?),gross_amount=?,deduction_amount=?,net_amount=?,source_hash=?,render_hash=?,summary_json=?,raw_reference_json=?,updated_at=UTC_TIMESTAMP() WHERE id=? AND company_id=?`,[payrollRunId,p.gross,p.deductions,p.net,p.sourceHash,p.renderHash,JSON.stringify(summary),JSON.stringify(p.rawReference),current.id,companyId]);
        const relative=`companies/${companyId}/payrolls/${p.year}/${String(p.month).padStart(2,'0')}/${current.id}/original.pdf`;const stored=await this.storage.write(relative,pdf);
        await conn.execute(`INSERT INTO payroll_documents (payroll_id,original_path,original_sha256,created_at,updated_at) VALUES (?,?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE original_path=VALUES(original_path),original_sha256=VALUES(original_sha256),updated_at=UTC_TIMESTAMP()`,[current.id,stored.path,stored.sha256]);
        await conn.execute(`UPDATE payrolls SET status=CASE WHEN status IN ('SIGNATURE_REQUESTED','VIEWED') THEN status ELSE 'READY' END,updated_at=UTC_TIMESTAMP() WHERE id=? AND company_id=?`,[current.id,companyId]);
        await conn.commit();return'repaired';
      }catch(error){await conn.rollback();throw error;}finally{conn.release();}
    }

    if(current&&String(current.status)==='SIGNED'){
      await this.audit.record({companyId,action:'PAYROLL_SOURCE_CHANGED_SIGNED_SKIPPED',targetType:'PAYROLL',targetId:current.id,metadata:{jobId:Number(job.id),payrollRunId,sageEmployeeCode:p.sageEmployeeCode,year:p.year,month:p.month,payrollType:p.payrollType}});
      return'unchanged';
    }

    const documentNumber=await this.allocateDocumentNumber(p.year,p.month);const pdf=this.payrollPdf(employee,p,documentNumber);const conn=await this.pool.getConnection();let payrollId=0;
    try{
      await conn.beginTransaction();
      const [lockedCurrentRows]=await conn.execute<RowDataPacket[]>(`SELECT id,version,source_hash sourceHash,status FROM payrolls WHERE company_id=? AND employee_id=? AND year=? AND month=? AND payroll_type=? AND is_current=1 ORDER BY version DESC LIMIT 1 FOR UPDATE`,[companyId,employee.id,p.year,p.month,p.payrollType]);
      const lockedCurrent=lockedCurrentRows[0];
      if((current?.id??null)!==(lockedCurrent?.id??null))throw new Error('A versão atual do holerite mudou durante a normalização; o job será retomado.');
      if(lockedCurrent&&String(lockedCurrent.status)==='SIGNED')throw new Error('Holerite assinado não pode ser substituído.');
      const version=lockedCurrent?Number(lockedCurrent.version)+1:1;
      if(lockedCurrent)await conn.execute(`UPDATE payrolls SET is_current=0,status=IF(status='SIGNED',status,'REPLACED'),updated_at=UTC_TIMESTAMP() WHERE id=? AND company_id=?`,[lockedCurrent.id,companyId]);
      const [insert]=await conn.execute<ResultSetHeader>(`INSERT INTO payrolls (document_number,company_id,employee_id,payroll_run_id,company_code,sage_employee_code,year,month,payroll_type,payroll_type_label,version,is_current,status,gross_amount,deduction_amount,net_amount,source_hash,render_hash,summary_json,raw_reference_json,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,1,'PROCESSING',?,?,?,?,?,?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())`,[documentNumber,companyId,employee.id,payrollRunId,String(job.companyCode),p.sageEmployeeCode,p.year,p.month,p.payrollType,p.payrollTypeLabel,version,p.gross,p.deductions,p.net,p.sourceHash,p.renderHash,JSON.stringify(summary),JSON.stringify(p.rawReference)]);payrollId=insert.insertId;
      await this.insertPayrollItems(conn,payrollId,p.items);
      const relative=`companies/${companyId}/payrolls/${p.year}/${String(p.month).padStart(2,'0')}/${payrollId}/original.pdf`;const stored=await this.storage.write(relative,pdf);
      await conn.execute(`INSERT INTO payroll_documents (payroll_id,original_path,original_sha256,created_at,updated_at) VALUES (?,?,?,UTC_TIMESTAMP(),UTC_TIMESTAMP())`,[payrollId,stored.path,stored.sha256]);
      await conn.execute(`UPDATE payrolls SET status='READY',updated_at=UTC_TIMESTAMP() WHERE id=? AND company_id=?`,[payrollId,companyId]);
      await conn.commit();return'created';
    }catch(error){await conn.rollback();if(payrollId>0)await this.storage.remove(`companies/${companyId}/payrolls/${p.year}/${String(p.month).padStart(2,'0')}/${payrollId}/original.pdf`);throw error;}finally{conn.release();}
  }

  async archiveCompletedJobRaw(jobId:number,companyId:number):Promise<{archived:number;bytesBefore:number;bytesAfter:number}>{
    const [rows]=await this.pool.execute<RowDataPacket[]>(`SELECT id,source_table sourceTable,batch_number batchNumber,payload_json payload,source_hash sourceHash FROM connector_raw_batches WHERE job_id=? AND company_id=? AND payload_json IS NOT NULL ORDER BY id`,[jobId,companyId]);
    let archived=0;let bytesBefore=0;let bytesAfter=0;
    for(const row of rows){
      const payload=String(row.payload??'');if(!payload)continue;
      const source=String(row.sourceTable??'batch').replace(/[^A-Za-z0-9._-]+/g,'_').slice(0,60)||'batch';
      const compressed=await gzipAsync(Buffer.from(payload,'utf8'),{level:6});
      const relative=`companies/${companyId}/imports/${jobId}/raw/${row.id}-${source}-${Number(row.batchNumber??0)}.json.gz`;
      const stored=await this.storage.write(relative,compressed);
      const [updated]=await this.pool.execute<ResultSetHeader>(`UPDATE connector_raw_batches SET archived_path=?,archived_sha256=?,archived_bytes=?,archived_at=UTC_TIMESTAMP(),payload_json=NULL WHERE id=? AND company_id=? AND job_id=? AND payload_json IS NOT NULL`,[stored.path,stored.sha256,compressed.length,row.id,companyId,jobId]);
      if(updated.affectedRows===1){archived++;bytesBefore+=Buffer.byteLength(payload,'utf8');bytesAfter+=compressed.length;}else await this.storage.remove(relative);
    }
    return{archived,bytesBefore,bytesAfter};
  }

  async normalizeClaimedJob(claim:NormalizationClaim,renew:()=>Promise<void>):Promise<NormalizationResult>{
    const job=await this.normalizationJob(claim);const normalized=await this.normalizedInput(job);const result:NormalizationResult={created:0,repaired:0,unchanged:0,skipped:0};
    const companyId=Number(job.companyId);const payrollRunId=job.payrollRunId==null?null:Number(job.payrollRunId);
    const employees=await this.preloadEmployees(companyId,normalized);const currents=await this.preloadCurrentPayrolls(companyId,employees,normalized);
    const concurrency=Math.max(1,Math.min(3,Number(process.env.PAYROLL_GENERATION_CONCURRENCY??1)||1));
    for(let start=0;start<normalized.length;start+=concurrency){
      const chunk=normalized.slice(start,start+concurrency);
      const outcomes=await Promise.all(chunk.map(async(payroll)=>{
        let employee=employees.get(String(payroll.sageEmployeeCode))??null;
        if(!employee)employee=await this.employeeForPayroll(companyId,payroll.sageEmployeeCode,Number(job.id),payrollRunId);
        const current=employee?currents.get(`${employee.id}|${payroll.year}|${payroll.month}|${payroll.payrollType}`)??null:null;
        let outcome:'created'|'repaired'|'unchanged'|'skipped'|null=null;for(let attempt=1;attempt<=3;attempt++){try{outcome=await this.persistNormalizedPayroll(job,payroll,employee,current);break;}catch(error){if(!isTransientDbLock(error)||attempt===3)throw error;await sleep(120*attempt+Math.floor(Math.random()*80));await renew();}}await renew();return outcome!;
      }));
      for(const outcome of outcomes)result[outcome]++;
    }
    return result;
  }

  async normalizeCompletedJob(jobId:number):Promise<{created:number;unchanged:number;skipped:number}>{
    const [rows]=await this.pool.execute<RowDataPacket[]>(`SELECT id,company_id companyId,payroll_run_id payrollRunId,status,normalized_at normalizedAt,normalization_state normalizationState,normalization_attempt_count attempts FROM import_jobs WHERE id=? LIMIT 1`,[jobId]);const row=rows[0];if(!row||row.status!=='COMPLETED'||row.normalizedAt)return{created:0,unchanged:0,skipped:0};
    const owner=`legacy-${process.pid}-${jobId}`;const [claimResult]=await this.pool.execute<ResultSetHeader>(`UPDATE import_jobs SET normalization_state='CLAIMED',normalization_owner=?,normalization_claimed_at=UTC_TIMESTAMP(),normalization_lease_until=DATE_ADD(UTC_TIMESTAMP(),INTERVAL 15 MINUTE),normalization_attempt_count=normalization_attempt_count+1,normalization_error=NULL,updated_at=UTC_TIMESTAMP() WHERE id=? AND company_id=? AND normalized_at IS NULL AND (normalization_state IS NULL OR normalization_state='PENDING' OR (normalization_state='CLAIMED' AND normalization_lease_until<UTC_TIMESTAMP()))`,[owner,jobId,row.companyId]);if(claimResult.affectedRows!==1)return{created:0,unchanged:0,skipped:0};
    const claim:NormalizationClaim={jobId,companyId:Number(row.companyId),payrollRunId:row.payrollRunId==null?null:Number(row.payrollRunId),owner,attempt:Number(row.attempts??0)+1};
    try{
      const result=await this.normalizeClaimedJob(claim,async()=>undefined);const conn=await this.pool.getConnection();
      try{
        await conn.beginTransaction();
        const [done]=await conn.execute<ResultSetHeader>(`UPDATE import_jobs SET normalization_state='COMPLETED',normalized_at=UTC_TIMESTAMP(),normalization_owner=NULL,normalization_lease_until=NULL,normalization_error=NULL,updated_at=UTC_TIMESTAMP() WHERE id=? AND company_id=? AND normalization_owner=? AND normalization_state='CLAIMED' AND normalized_at IS NULL`,[jobId,claim.companyId,owner]);
        if(done.affectedRows!==1)throw new Error(`Não foi possível concluir o job legado #${jobId}.`);
        if(claim.payrollRunId){const status=result.skipped>0?'PARTIAL':'COMPLETED';await conn.execute(`UPDATE payroll_runs SET status=?,success_count=?,failure_count=?,message=?,finished_at=UTC_TIMESTAMP() WHERE id=? AND company_id=? AND status IN ('QUEUED','RUNNING')`,[status,result.created+result.repaired+result.unchanged,result.skipped,`${result.created} novo(s), ${result.repaired} reparado(s), ${result.unchanged} sem alteração, ${result.skipped} ignorado(s).`.slice(0,500),claim.payrollRunId,claim.companyId]);}
        await conn.commit();
      }catch(error){await conn.rollback();throw error;}finally{conn.release();}
      await this.notifications.notifyAdmins(claim.companyId,{category:'IMPORT_COMPLETED',title:'Importação de holerites concluída',body:`${result.created} novo(s), ${result.repaired} reparado(s), ${result.unchanged} sem alteração e ${result.skipped} ignorado(s).`,url:'/#/payrolls',dedupKey:`import-completed:${jobId}`});
      try{await this.archiveCompletedJobRaw(jobId,claim.companyId);}catch(error){console.error(`[payroll] falha ao arquivar batches brutos do job ${jobId}`,error);}
      return{created:result.created,unchanged:result.unchanged+result.repaired,skipped:result.skipped};
    }catch(error){await this.pool.execute(`UPDATE import_jobs SET normalization_state='PENDING',normalization_owner=NULL,normalization_lease_until=NULL,normalization_error=?,updated_at=UTC_TIMESTAMP() WHERE id=? AND company_id=? AND normalization_owner=?`,[(error instanceof Error?error.message:String(error)).slice(0,1000),jobId,claim.companyId,owner]);throw error;}
  }

  private adminWhere(context:UserContext,filters:PayrollAdminFilters={}):{where:string[];params:Array<number|string>}{
    const where=['p.company_id=?','p.is_current=1'];const params:Array<number|string>=[context.companyId];
    if(filters.employeeId){where.push('p.employee_id=?');params.push(filters.employeeId);}
    if(filters.groupId){where.push('e.group_id=?');params.push(filters.groupId);}
    if(filters.year){where.push('p.year=?');params.push(filters.year);}
    if(filters.month){where.push('p.month=?');params.push(filters.month);}
    if(filters.status){where.push('p.status=?');params.push(filters.status);}
    if(filters.type){where.push('p.payroll_type=?');params.push(filters.type);}
    const search=String(filters.search??'').trim();if(search){const like=`%${search}%`;const digits=search.replace(/\D/g,'');where.push(`(e.name LIKE ? OR e.cpf LIKE ? OR p.document_number LIKE ? OR g.name LIKE ? OR p.payroll_type_label LIKE ?${digits?' OR e.cpf LIKE ?':''})`);params.push(like,like,like,like,like);if(digits)params.push(`%${digits}%`);}
    return{where,params};
  }

  async listAdminPage(context:UserContext,filters:PayrollAdminPageFilters={}):Promise<{payrolls:Record<string,unknown>[];total:number;page:number;pageSize:number}>{
    const page=Math.max(1,Number(filters.page??1)||1);const pageSize=Math.max(10,Math.min(100,Number(filters.pageSize??25)||25));const offset=(page-1)*pageSize;const {where,params}=this.adminWhere(context,filters);
    const sort=String(filters.sort??'newest');const orderBy=sort==='name'?'e.name ASC,p.year DESC,p.month DESC,p.payroll_type ASC':sort==='net-desc'?'p.net_amount DESC,e.name ASC,p.year DESC,p.month DESC':sort==='status'?'p.status ASC,e.name ASC,p.year DESC,p.month DESC':'p.year DESC,p.month DESC,e.name ASC,p.payroll_type ASC';
    const [countRows]=await this.pool.execute<RowDataPacket[]>(`SELECT COUNT(*) value FROM payrolls p JOIN employees e ON e.id=p.employee_id AND e.company_id=p.company_id JOIN employee_groups g ON g.id=e.group_id AND g.company_id=p.company_id WHERE ${where.join(' AND ')}`,params);
    const total=Number(countRows[0]?.value??0);const [rows]=await this.pool.execute<RowDataPacket[]>(`SELECT p.id,p.document_number documentNumber,p.employee_id employeeId,e.name employeeName,e.cpf,e.group_id groupId,g.name groupName,p.year,p.month,p.payroll_type payrollType,p.payroll_type_label payrollTypeLabel,p.version,p.status,p.gross_amount grossAmount,p.deduction_amount deductionAmount,p.net_amount netAmount,p.released_at releasedAt,p.signed_at signedAt,p.created_at createdAt,d.original_sha256 originalSha256,d.signed_sha256 signedSha256 FROM payrolls p JOIN employees e ON e.id=p.employee_id AND e.company_id=p.company_id JOIN employee_groups g ON g.id=e.group_id AND g.company_id=p.company_id LEFT JOIN payroll_documents d ON d.payroll_id=p.id WHERE ${where.join(' AND ')} ORDER BY ${orderBy} LIMIT ? OFFSET ?`,[...params,pageSize,offset]);
    return{payrolls:rows,total,page,pageSize};
  }

  async listAdminSelection(context:UserContext,filters:PayrollAdminFilters={}):Promise<Array<{id:number;status:string}>>{
    const {where,params}=this.adminWhere(context,filters);const [rows]=await this.pool.execute<RowDataPacket[]>(`SELECT p.id,p.status FROM payrolls p JOIN employees e ON e.id=p.employee_id AND e.company_id=p.company_id JOIN employee_groups g ON g.id=e.group_id AND g.company_id=p.company_id WHERE ${where.join(' AND ')} ORDER BY p.id LIMIT 5000`,params);return rows.map((row)=>({id:Number(row.id),status:String(row.status)}));
  }

  async listAdmin(context:UserContext,filters:PayrollAdminFilters={}):Promise<Record<string,unknown>[]> {
    const {where,params}=this.adminWhere(context,filters);
    const [rows]=await this.pool.execute<RowDataPacket[]>(`SELECT p.id,p.document_number documentNumber,p.employee_id employeeId,e.name employeeName,e.cpf,e.group_id groupId,g.name groupName,p.year,p.month,p.payroll_type payrollType,p.payroll_type_label payrollTypeLabel,p.version,p.status,p.gross_amount grossAmount,p.deduction_amount deductionAmount,p.net_amount netAmount,p.released_at releasedAt,p.signed_at signedAt,p.created_at createdAt,d.original_sha256 originalSha256,d.signed_sha256 signedSha256 FROM payrolls p JOIN employees e ON e.id=p.employee_id AND e.company_id=p.company_id JOIN employee_groups g ON g.id=e.group_id AND g.company_id=p.company_id LEFT JOIN payroll_documents d ON d.payroll_id=p.id WHERE ${where.join(' AND ')} ORDER BY p.year DESC,p.month DESC,e.name ASC,p.payroll_type ASC LIMIT 5000`,params);return rows;
  }

  async listEmployee(context:EmployeeContext):Promise<Record<string,unknown>[]>{const [rows]=await this.pool.execute<RowDataPacket[]>(`SELECT p.id,p.document_number documentNumber,p.year,p.month,p.payroll_type payrollType,p.payroll_type_label payrollTypeLabel,p.status,p.gross_amount grossAmount,p.deduction_amount deductionAmount,p.net_amount netAmount,p.released_at releasedAt,p.signed_at signedAt FROM payrolls p WHERE p.employee_id=? AND p.company_id=? AND p.is_current=1 AND p.status IN ('SIGNATURE_REQUESTED','VIEWED','SIGNED') ORDER BY p.year DESC,p.month DESC,p.payroll_type`,[context.employeeId,context.companyId]);return rows;}

  async detail(context:RequestContext,payrollId:number):Promise<Record<string,unknown>>{
    const params:number[]=[payrollId,context.companyId];let employeeClause='';if(context.kind==='EMPLOYEE'){employeeClause=' AND p.employee_id=? AND p.status IN (\'SIGNATURE_REQUESTED\',\'VIEWED\',\'SIGNED\')';params.push(context.employeeId);}
    const [rows]=await this.pool.execute<RowDataPacket[]>(`SELECT p.*,e.name employeeName,e.cpf,e.sage_employee_code sageCode,e.job_title jobTitle,DATE_FORMAT(e.admission_date,'%Y-%m-%d') admissionDate,e.sage_snapshot_json sageSnapshotJson,g.name groupName,d.original_sha256 originalSha256,d.signed_sha256 signedSha256,d.receipt_sha256 receiptSha256,sr.id signatureRequestId,sr.status signatureStatus,sr.acceptance_text acceptanceText,aset.signature_mode signatureMode FROM payrolls p JOIN employees e ON e.id=p.employee_id AND e.company_id=p.company_id JOIN employee_groups g ON g.id=e.group_id AND g.company_id=p.company_id LEFT JOIN payroll_documents d ON d.payroll_id=p.id LEFT JOIN signature_requests sr ON sr.payroll_id=p.id LEFT JOIN app_settings aset ON aset.company_id=p.company_id WHERE p.id=? AND p.company_id=? ${employeeClause} LIMIT 1`,params);const row=rows[0];if(!row)throw notFound('Holerite não encontrado.');const cbo=sageSnapshotValue(row.sageSnapshotJson,cboAliases);delete row.sageSnapshotJson;
    if(row.acceptanceText)row.acceptanceText=withSignatureEvidenceDisclosure(String(row.acceptanceText));
    const [items]=await this.pool.execute<RowDataPacket[]>(`SELECT event_code eventCode,description,reference_value referenceValue,amount,nature,sort_order sortOrder FROM payroll_items WHERE payroll_id=? ORDER BY sort_order,id`,[payrollId]);return{...row,cbo,summary:parseJson(row.summary_json,{}),summary_json:undefined,rawReference:parseJson(row.raw_reference_json,{}),raw_reference_json:undefined,items};
  }

  async release(context:UserContext,payrollId:number,acceptanceText:string,meta:RequestMeta):Promise<number>{
    const [rows]=await this.pool.execute<RowDataPacket[]>(`SELECT employee_id employeeId,status FROM payrolls WHERE id=? AND company_id=? AND is_current=1 LIMIT 1`,[payrollId,context.companyId]);const row=rows[0];if(!row)throw notFound('Holerite não encontrado.');if(!['READY','SIGNATURE_REQUESTED','VIEWED'].includes(String(row.status)))throw badRequest('Este holerite não pode ser liberado neste status.');
    acceptanceText=withSignatureEvidenceDisclosure(acceptanceText);const {sha256}=await import('../core/security.js');const hash=sha256(acceptanceText);
    await this.pool.execute(`INSERT INTO signature_requests (payroll_id,employee_id,requested_by_user_id,status,acceptance_text,acceptance_text_hash,requested_at) VALUES (?,?,?,'PENDING',?,?,UTC_TIMESTAMP()) ON DUPLICATE KEY UPDATE requested_by_user_id=VALUES(requested_by_user_id),status=IF(status='SIGNED',status,'PENDING'),acceptance_text=VALUES(acceptance_text),acceptance_text_hash=VALUES(acceptance_text_hash),requested_at=IF(status='SIGNED',requested_at,UTC_TIMESTAMP())`,[payrollId,row.employeeId,context.userId,acceptanceText,hash]);
    await this.pool.execute(`UPDATE payrolls SET status=IF(status='SIGNED',status,'SIGNATURE_REQUESTED'),released_at=COALESCE(released_at,UTC_TIMESTAMP()),updated_at=UTC_TIMESTAMP() WHERE id=? AND company_id=?`,[payrollId,context.companyId]);
    const [requestRows]=await this.pool.execute<RowDataPacket[]>(`SELECT id FROM signature_requests WHERE payroll_id=? LIMIT 1`,[payrollId]);const requestId=Number(requestRows[0]!.id);
    await this.audit.record({companyId:context.companyId,actorUserId:context.userId,action:'PAYROLL_SIGNATURE_REQUESTED',targetType:'PAYROLL',targetId:payrollId,meta,metadata:{signatureRequestId:requestId}});
    const [notifyRows]=await this.pool.execute<RowDataPacket[]>(`SELECT p.year,p.month,p.payroll_type_label typeLabel,e.name FROM payrolls p JOIN employees e ON e.id=p.employee_id AND e.company_id=p.company_id WHERE p.id=? AND p.company_id=? LIMIT 1`,[payrollId,context.companyId]);const n=notifyRows[0];
    await this.notifications.notifyEmployee(context.companyId,Number(row.employeeId),{category:'PAYROLL_AVAILABLE',title:'Novo holerite para assinatura',body:n?`${String(n.typeLabel)} de ${String(n.month).padStart(2,'0')}/${n.year} está disponível.`:'Seu holerite está disponível para assinatura.',url:'/#/employee',dedupKey:`payroll-release:${payrollId}`});
    return requestId;
  }

  async markViewed(context:EmployeeContext,payrollId:number,meta:RequestMeta):Promise<void>{const [result]=await this.pool.execute<ResultSetHeader>(`UPDATE payrolls SET status=IF(status='SIGNATURE_REQUESTED','VIEWED',status),updated_at=UTC_TIMESTAMP() WHERE id=? AND employee_id=? AND company_id=? AND status IN ('SIGNATURE_REQUESTED','VIEWED','SIGNED')`,[payrollId,context.employeeId,context.companyId]);if(result.affectedRows===0)throw notFound('Holerite não encontrado.');await this.pool.execute(`INSERT INTO document_access_logs (payroll_id,actor_type,actor_id,action,ip_address,user_agent,created_at) VALUES (?,'EMPLOYEE',?,'VIEW_FULL',?,?,UTC_TIMESTAMP())`,[payrollId,context.employeeId,meta.ipAddress,meta.userAgent]);}

  private async readOriginalWithoutLegacyFooter(payrollId:number,path:string):Promise<{buffer:Buffer;sha256:string}>{const buffer=await this.storage.read(path);const marker=Buffer.from(legacyPayrollFooter,'latin1');let index=buffer.indexOf(marker);if(index<0){const {sha256}=await import('../core/security.js');return{buffer,sha256:sha256(buffer)};}const cleaned=Buffer.from(buffer);while(index>=0){cleaned.fill(0x20,index,index+marker.length);index=cleaned.indexOf(marker,index+marker.length);}const stored=await this.storage.write(path,cleaned);await this.pool.execute(`UPDATE payroll_documents SET original_sha256=?,updated_at=UTC_TIMESTAMP() WHERE payroll_id=?`,[stored.sha256,payrollId]);return{buffer:cleaned,sha256:stored.sha256};}

  async originalDocument(context:RequestContext,payrollId:number):Promise<{buffer:Buffer;filename:string}>{const params=[payrollId,context.companyId];const employeeClause=context.kind==='EMPLOYEE'?` AND p.employee_id=? AND p.status IN ('SIGNATURE_REQUESTED','VIEWED','SIGNED')`:'';if(context.kind==='EMPLOYEE')params.push(context.employeeId);const [rows]=await this.pool.execute<RowDataPacket[]>(`SELECT d.original_path path,p.year,p.month,p.payroll_type payrollType FROM payroll_documents d JOIN payrolls p ON p.id=d.payroll_id WHERE d.payroll_id=? AND p.company_id=?${employeeClause} LIMIT 1`,params);const row=rows[0];if(!row)throw notFound('Documento não encontrado.');const doc=await this.readOriginalWithoutLegacyFooter(payrollId,String(row.path));return{buffer:doc.buffer,filename:`holerite-${row.year}-${String(row.month).padStart(2,'0')}-tipo-${row.payrollType}.pdf`};}

  async adminDocument(context:UserContext,payrollId:number):Promise<{buffer:Buffer;filename:string;kind:'ASSINADO'|'ORIGINAL'}>{
    const [rows]=await this.pool.execute<RowDataPacket[]>(`SELECT p.status,p.year,p.month,p.payroll_type payrollType,e.name employeeName,d.original_path originalPath,d.original_sha256 originalSha,d.signed_path signedPath,d.signed_sha256 signedSha FROM payrolls p JOIN employees e ON e.id=p.employee_id AND e.company_id=p.company_id JOIN payroll_documents d ON d.payroll_id=p.id WHERE p.id=? AND p.company_id=? LIMIT 1`,[payrollId,context.companyId]);
    const row=rows[0];if(!row)throw notFound('Documento não encontrado.');const signed=Boolean(row.signedPath);const path=String(signed?row.signedPath:row.originalPath);const kind=signed?'ASSINADO':'ORIGINAL';const name=exportFileSafe(String(row.employeeName));const buffer=signed?await this.storage.read(path):(await this.readOriginalWithoutLegacyFooter(payrollId,path)).buffer;return{buffer,filename:`${name}_${row.year}-${String(row.month).padStart(2,'0')}_TIPO-${row.payrollType}_${kind}.pdf`,kind};
  }

  async exportDocuments(context:UserContext,payrollIds:number[],meta:RequestMeta):Promise<PayrollExportEntry[]>{
    const ids=[...new Set(payrollIds.filter((id)=>Number.isInteger(id)&&id>0))];if(ids.length===0)throw badRequest('Selecione ao menos um holerite.');if(ids.length>200)throw badRequest('A exportação permite até 200 holerites por vez.');
    const placeholders=ids.map(()=>'?').join(',');const [rows]=await this.pool.execute<RowDataPacket[]>(`SELECT p.id,p.status,p.year,p.month,p.payroll_type payrollType,p.payroll_type_label typeLabel,e.name employeeName,d.original_path originalPath,d.original_sha256 originalSha,d.signed_path signedPath,d.signed_sha256 signedSha FROM payrolls p JOIN employees e ON e.id=p.employee_id AND e.company_id=p.company_id JOIN payroll_documents d ON d.payroll_id=p.id WHERE p.company_id=? AND p.id IN (${placeholders}) AND p.is_current=1 ORDER BY e.name,p.year,p.month,p.payroll_type`,[context.companyId,...ids]);
    if(rows.length!==ids.length)throw notFound('Um ou mais holerites selecionados não foram encontrados.');
    const entries:PayrollExportEntry[]=[];for(const row of rows){const signed=Boolean(row.signedPath);const kind=signed?'ASSINADO':'ORIGINAL';const path=String(signed?row.signedPath:row.originalPath);let buffer:Buffer;let sha:string;if(signed){buffer=await this.storage.read(path);sha=String(row.signedSha);}else{const original=await this.readOriginalWithoutLegacyFooter(Number(row.id),path);buffer=original.buffer;sha=original.sha256;}const competence=`${String(row.month).padStart(2,'0')}/${row.year}`;const filename=`${exportFileSafe(String(row.employeeName))}_${row.year}-${String(row.month).padStart(2,'0')}_${exportFileSafe(String(row.typeLabel))}_${kind}.pdf`;entries.push({payrollId:Number(row.id),employeeName:String(row.employeeName),competence,typeLabel:String(row.typeLabel),status:String(row.status),documentKind:kind,sha256:sha,filename,buffer});await this.pool.execute(`INSERT INTO document_access_logs (payroll_id,actor_type,actor_id,action,ip_address,user_agent,created_at) VALUES (?,'USER',?,'DOWNLOAD',?,?,UTC_TIMESTAMP())`,[Number(row.id),context.userId,meta.ipAddress,meta.userAgent]);}
    return entries;
  }

  async employeeDownload(context:EmployeeContext,payrollId:number,meta:RequestMeta):Promise<{buffer:Buffer;filename:string}>{const [rows]=await this.pool.execute<RowDataPacket[]>(`SELECT d.signed_path path,p.year,p.month,p.payroll_type payrollType FROM payroll_documents d JOIN payrolls p ON p.id=d.payroll_id WHERE d.payroll_id=? AND p.employee_id=? AND p.company_id=? AND p.status='SIGNED' LIMIT 1`,[payrollId,context.employeeId,context.companyId]);const row=rows[0];if(!row||!row.path)throw badRequest('O download é liberado somente após a assinatura.');await this.pool.execute(`INSERT INTO document_access_logs (payroll_id,actor_type,actor_id,action,ip_address,user_agent,created_at) VALUES (?,'EMPLOYEE',?,'DOWNLOAD',?,?,UTC_TIMESTAMP())`,[payrollId,context.employeeId,meta.ipAddress,meta.userAgent]);return{buffer:await this.storage.read(String(row.path)),filename:`holerite-assinado-${row.year}-${String(row.month).padStart(2,'0')}.pdf`};}
}
