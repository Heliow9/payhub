import {createContext,useContext,useEffect,useMemo,useState,type ReactNode} from 'react';
import {api,clearSession,restoreSessionSecrets,type Principal} from '../lib/api';

type AuthValue={principal:Principal|null;loading:boolean;login(cpf:string,pin:string):Promise<void>;firstAccess(cpf:string,birthDate:string,pin:string):Promise<void>;logout():Promise<void>;refresh():Promise<void>};
const AuthContext=createContext<AuthValue|null>(null);
export function AuthProvider({children}:{children:ReactNode}){
  const[principal,setPrincipal]=useState<Principal|null>(null); const[loading,setLoading]=useState(true);
  async function refresh(){try{const r=await api.me();setPrincipal(r.principal);if(!r.principal)await clearSession();}catch{setPrincipal(null);await clearSession();}}
  useEffect(()=>{void restoreSessionSecrets().then(refresh).finally(()=>setLoading(false));},[]);
  const value=useMemo<AuthValue>(()=>({principal,loading,async login(cpf,pin){const r=await api.login(cpf,pin);setPrincipal(r.principal);},async firstAccess(cpf,birthDate,pin){const r=await api.firstAccess(cpf,birthDate,pin);setPrincipal(r.principal);},async logout(){await api.logout().catch(()=>clearSession());setPrincipal(null);},refresh}),[principal,loading]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export function useAuth(){const v=useContext(AuthContext);if(!v)throw new Error('AuthProvider ausente');return v;}
