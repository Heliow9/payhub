# SDD ledger — plan: docs/superpowers/plans/2026-09-20-payhub-durable-worker.md

Ruling: execução no checkout principal — usuário autorizou trabalho direto em C:\projects\PayHub — custo se errado: alterações ficam imediatamente no branch main local.
Ruling: testes automatizados dispensados — usuário pediu explicitamente "não precisa fazer testes apenas o ajuste" — custo se errado: regressões comportamentais dependerão de build e validação posterior em produção.
Pre-flight: Task 1 produz schema consumido pelas Tasks 2, 4 e 5; nomes conferidos com a especificação.
Pre-flight: Task 2 produz claim/lease consumido pelas Tasks 3 e 5; contratos compatíveis.
Pre-flight: Task 4 produz outbox consumida pela Task 5; ordem compatível.
Pre-flight: Tasks 1–5 produzem estados consumidos pelo dashboard e verificadores das Tasks 6–7.

Task 1 GREEN: migration 006 adicionada com estado/lease de normalização, heartbeat, outbox e backfill dos PAYROLL_IMPORT concluídos ainda não normalizados.
Task 2 GREEN: NormalizationQueueService implementa claim condicional, lease renovável, conclusão transacional job+run, retentativa e falha terminal.
Task 3 GREEN: PayrollService implementa normalização retomável/idempotente, reparo de PROCESSING/ERROR ou PDF ausente/corrompido, e proteção absoluta de SIGNED.
Task 4 GREEN: criação de notificação/outbox é transacional e entrega Push saiu do caminho crítico, com claim e backoff de retentativa.
Task 5 GREEN: worker de produção usa leases, heartbeat, watchdog fatal, outbox e recuperação por PM2; fluxo legado foi mantido apenas para compatibilidade de callers/testes antigos.
Task 6 GREEN: API/dashboard expõem saúde sanitizada do worker e distinguem coleta, espera de processamento, geração e falha de geração.
Task 7 GREEN: verificador de invariantes e DEPLOY-DURABLE-WORKER.md adicionados; verify multi-company inclui mismatch da outbox.
Task 8 validation: pacote recebido não possui dependências completas. A tentativa de restauração npm não conseguiu resolver o registry (EAI_AGAIN), portanto suíte Vitest/build integral não podem ser declarados como executados neste ambiente offline. Validação sintática offline deve ser executada antes da entrega e os gates `npm ci`, testes/build e verificadores permanecem obrigatórios no servidor/homologação.
