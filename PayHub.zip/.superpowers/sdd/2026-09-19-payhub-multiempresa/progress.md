# SDD ledger — plan: docs/superpowers/plans/2026-09-19-payhub-multiempresa.md
Execution BASE: fcc16d6
Execution mode: inline in the user-approved current checkout; no worktree.
Setup Ruling: Superpowers helper scripts require Bash, unavailable on this Windows host — use the same workspace/brief/ledger format through native PowerShell and apply_patch — cost if wrong: helper-generated metadata may differ, while commits and test evidence remain authoritative.
Pre-flight Task 1 → Tasks 2-8: schema names and company/identity columns match their consumers; app_settings requires company_id and will be migrated in Task 1.
Pre-flight Task 2 → Tasks 3-10: Principal and RequestContext names match all consumers.
Pre-flight Task 3 → Tasks 9-10: AuthOutcome/selection contract matches web and mobile consumers.
Pre-flight Task 4 → Task 11: provisionCompany result and idempotency contract match the smoke-test consumer.
Pre-flight Task 5 → Tasks 6-8: connector/job companyId scope matches payroll-run, normalizer and worker consumers.
Pre-flight Task 6 → Task 7: UserContext/EmployeeContext and payroll company ownership match the document/signature consumer.
Task 1 Ruling: the plan's migration test inspects SQL text, which is weaker than executing MySQL — retain it only as a fast guard because no disposable MySQL is configured, and require the real verifier on a cloned/homologation database before deployment — cost if wrong: a MySQL-specific DDL error is caught at homologation rather than unit-test time.
Task 1: complete (commits fcc16d6..7ee74e0, tests: npm test --workspace @payhub/api -- src/tests/multi-company-migration.test.ts → 3/3 pass)
Task 1 baseline: full API suite is 44/49 with five pre-existing failures in src/app.test.ts caused by its obsolete createApp fixture; API build has pre-existing MYSQL_* vs DB_* errors in src/infra/db/mysql.ts and src/scripts/migrate.ts. Both are assigned to Task 11/baseline cleanup, not introduced by Task 1.
Task 2 Ruling: pre-existing uncommitted Bearer/mobile authentication overlaps middleware/auth.ts and routes/auth.routes.ts and is required by the approved mobile multiempresa flow — preserve it and include it when each overlapping file is first committed instead of reverting or splitting minified lines — cost if wrong: the feature commits also take ownership of those compatible mobile-auth changes.
Task 2: complete (commits 7ee74e0..9987e39, tests: npm test --workspace @payhub/api -- src/tests/tenant-context.test.ts src/tests/auth-compat.test.ts → 5/5 pass)

Task 3 RED: employee-multi-company-auth.test.ts failed because authentication still read per-company employee credentials and company selection did not exist.
Task 3 GREEN: employee authentication now uses the global CPF identity/PIN, returns validated company choices for multiple links, supports one-use selection tokens and company switching, and permits historical access for terminated links.
Task 3 verification: 7 focused authentication/context tests passed. TypeScript reports no new Task 3 errors; only the previously recorded legacy MYSQL_* environment-name errors remain.
Task 3: complete.

Task 4 RED: admin-tenancy.test.ts failed because the provisioning service did not exist.
Task 4 GREEN: added transactional/idempotent company provisioning, global admin-email validation, one MASTER mapping, per-company settings and session-forced analyst scope. The legacy bootstrap now only provisions an entirely empty database.
Task 4 verification: 6 focused administration/context tests passed; build has only the recorded legacy MYSQL_* errors.
Task 4: complete.

Task 5 RED: connector-tenancy.test.ts showed claim/list operations did not bind a company.
Task 5 GREEN: connector authentication now yields company context; connector, job, log and raw-batch operations require it; canonical Sage company code is loaded server-side.
Task 5 verification: 3 connector isolation tests passed. Build call-site errors in employee/payroll-run services are the expected Task 6 interface migration and will be resolved immediately next.
Task 5: complete.

Task 6 RED: resource-tenancy.test.ts was introduced to require company predicates and global-identity reuse.
Task 6 GREEN: groups, employees, lookups, synchronization and payroll runs now receive session context; IDs are constrained by company; Sage code is derived from company configuration; an existing CPF reuses its identity/PIN without rewriting credentials.
Task 6 verification: 14 focused resource/manual-search/employee tests passed. The only new build call-site remaining is the worker scheduler, intentionally handled in Task 8.
Task 6: complete.

Task 7 RED: resource-tenancy tests were extended for cross-company export and historical-signature denial.
Task 7 GREEN: payroll normalization derives company from the persisted job, new document paths include company, admin/employee reads and exports are company-scoped, public links resolve company through payroll, and signature PIN validation uses the global identity. Historical links can read signed documents but cannot sign.
Task 7 verification: 13 focused payroll/PDF/signature tests passed; TypeScript has no new Task 7 errors.
Task 7: complete.

Task 8 RED/GAP: o pacote recebido tinha Audit/Notification parcialmente migrados, porém dashboard e worker ainda executavam consultas globais; NotificationService já exigia companyId enquanto call-sites antigos ainda usavam a assinatura monoempresa.
Task 8 GREEN: dashboard passou a filtrar todos os KPIs/connectors/runs por company_id; chamadas de notificação carregam companyId; worker preserva companyId em normalização, agenda e alertas, isola falhas por item e possui main guard para teste. Criado worker-tenancy.test.ts com cenários de destinatários, agenda e falha cruzada.
Task 8 verification: auditoria estática confirma company_id nos KPIs e argumentos de notifyAdmins/notifyEmployee. Runtime Vitest não pôde ser executado no arquivo entregue porque node_modules não estava incluído e a restauração npm não obteve retorno de rede nesta execução.
Task 8: implementation complete; runtime test pending dependency restore.

Task 9 GREEN: contrato Web agora aceita AuthOutcome intermediário; seleção de empresa não persiste CSRF/principal antes da escolha; criada rota autenticada para listar vínculos; select/switch company implementados; token temporário é descartado em cancelamento/401; portal mostra empresa atual, vínculo histórico e troca de empresa; troca remonta o portal para limpar estado/caches locais; textos fixos "Empresa 1" foram removidos de Funcionários/Grupos.
Task 9 tests added/updated: company-selection.test.ts, AuthProvider.test.tsx e LoginPage.test.tsx cobrem estado anônimo durante seleção, escolha de vínculo histórico e UI do seletor.
Task 9 verification: busca estática não encontra Empresa 1/Empresa Sage fixa em código operacional. Build Web depende de node_modules ausente no ZIP.
Task 9: implementation complete; runtime test/build pending dependency restore.

Task 10 GREEN: mobile API aceita resultado intermediário sem exigir accessToken; saveSession só ocorre com sessão definitiva; seleção de empresa e troca de empresa foram implementadas; switch revoga a sessão anterior no servidor, limpa SecureStore e persiste somente o novo token/CSRF; login renderiza CompanySelector antes de navegar; layout do funcionário exibe empresa/vínculo e ação Trocar; navigator é remontado após mudança de contexto.
Task 10 verification: o módulo puro apps/mobile/src/auth/company-selection.ts passou em `tsc --noEmit --jsx react-jsx --moduleResolution bundler --module esnext --target es2022`. O workspace mobile continua sem package.json, conforme limitação preexistente registrada no plano.
Task 10: complete within the approved no-mobile-workspace constraint.

Task 11 GREEN: app.test.ts obsoleto foi substituído por fixture HTTP da pilha createApp atual cobrindo MASTER RealEnergy, 404 cross-company e seleção após CPF multi-vínculo; migration test ampliado; verificador recebeu checks adicionais de mismatch por empresa; variáveis legadas MYSQL_* em fontes ainda compiladas foram alinhadas para DB_*; README descreve arquitetura multiempresa; DEPLOY-MULTIEMPRESA.md criado com backup, hashes, clone/homologação, migration, verify, regressão, smoke test e rollback.
Task 11 static verification: transpile sintático dos arquivos TypeScript/TSX alterados sem erros; `rg` do plano não encontra regra operacional fixa de empresa 1; revisão das queries de raiz confirma filtros company_id ou fluxo global intencional que deriva companyId por registro (autenticação/worker/provisionamento).
Task 11 environment limitation: `npm test` retorna exit 127 porque vitest não existe sem node_modules; `npm run build` para antes do typecheck por ausência de @types/node, vite/client e vitest/globals. Tentativa de npm install ficou bloqueada sem saída de rede e foi encerrada. `npm run verify:multi-company` não foi executado contra banco porque o pacote não contém acesso a um clone/homologação MySQL, e não deve ser apontado ao banco de produção durante revisão offline.
Task 11: implementation complete; deployment gate remains the documented npm ci/test/build + verifier/smoke test on a cloned database.

Final verification ruling: source implementation is complete for Tasks 8-11. Do not claim production approval until DEPLOY-MULTIEMPRESA.md is executed successfully on homologation. The archive supplied has no .git directory, therefore Superpowers commit steps cannot be produced from this checkout; ledger evidence and file diff are the authority for this delivery.
