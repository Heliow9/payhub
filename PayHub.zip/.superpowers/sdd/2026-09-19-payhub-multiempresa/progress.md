# SDD ledger — plan: docs/superpowers/plans/2026-09-19-payhub-multiempresa.md
Execution BASE: fcc16d6
Execution mode: inline in the user-approved current checkout; no worktree.
Setup Ruling: Superpowers helper scripts require Bash, unavailable on this Windows host — use the same workspace/brief/ledger format through native PowerShell and apply_patch — cost if wrong: helper-generated metadata may differ, while commits and test evidence remain authoritative.
Pre-flight Task 1 → Tasks 2-8: schema names and company/identity columns match their consumers; app_settings requires company_id and will be migrated in Task 1.
Pre-flight Task 2 → Tasks 3-10: Principal and RequestContext names match all consumers.
Pre-flight Task 3 → Tasks 9-10: AuthOutcome/selection contract matches web and mobile consumers.
Pre-flight Task 4 → Task 11: provisionCompany result and idempotency contract match the smoke-test consumer.
Pre-flight Task 5 → Tasks 6-8: connector/job companyId scope matches payroll-run, normalizer and worker consumers.
Pre-flight Task 6 → Task 7: UserContext/EmployeeContext and payroll company ownership match the document/signature consumer.
Task 1 Ruling: the plan's migration test inspects SQL text, which is weaker than executing MySQL — retain it only as a fast guard because no disposable MySQL is configured, and require the real verifier on a cloned/homologation database before deployment — cost if wrong: a MySQL-specific DDL error is caught at homologation rather than unit-test time.
Task 1: complete (commits fcc16d6..7ee74e0, tests: npm test --workspace @payhub/api -- src/tests/multi-company-migration.test.ts → 3/3 pass)
Task 1 baseline: full API suite is 44/49 with five pre-existing failures in src/app.test.ts caused by its obsolete createApp fixture; API build has pre-existing MYSQL_* vs DB_* errors in src/infra/db/mysql.ts and src/scripts/migrate.ts. Both are assigned to Task 11/baseline cleanup, not introduced by Task 1.
Task 2 Ruling: pre-existing uncommitted Bearer/mobile authentication overlaps middleware/auth.ts and routes/auth.routes.ts and is required by the approved mobile multiempresa flow — preserve it and include it when each overlapping file is first committed instead of reverting or splitting minified lines — cost if wrong: the feature commits also take ownership of those compatible mobile-auth changes.
Task 2: complete (commits 7ee74e0..9987e39, tests: npm test --workspace @payhub/api -- src/tests/tenant-context.test.ts src/tests/auth-compat.test.ts → 5/5 pass)

Task 3 RED: employee-multi-company-auth.test.ts failed because authentication still read per-company employee credentials and company selection did not exist.
Task 3 GREEN: employee authentication now uses the global CPF identity/PIN, returns validated company choices for multiple links, supports one-use selection tokens and company switching, and permits historical access for terminated links.
Task 3 verification: 7 focused authentication/context tests passed. TypeScript reports no new Task 3 errors; only the previously recorded legacy MYSQL_* environment-name errors remain.
Task 3: complete.

Task 4 RED: admin-tenancy.test.ts failed because the provisioning service did not exist.
Task 4 GREEN: added transactional/idempotent company provisioning, global admin-email validation, one MASTER mapping, per-company settings and session-forced analyst scope. The legacy bootstrap now only provisions an entirely empty database.
Task 4 verification: 6 focused administration/context tests passed; build has only the recorded legacy MYSQL_* errors.
Task 4: complete.

Task 5 RED: connector-tenancy.test.ts showed claim/list operations did not bind a company.
Task 5 GREEN: connector authentication now yields company context; connector, job, log and raw-batch operations require it; canonical Sage company code is loaded server-side.
Task 5 verification: 3 connector isolation tests passed. Build call-site errors in employee/payroll-run services are the expected Task 6 interface migration and will be resolved immediately next.
Task 5: complete.

Task 6 RED: resource-tenancy.test.ts was introduced to require company predicates and global-identity reuse.
Task 6 GREEN: groups, employees, lookups, synchronization and payroll runs now receive session context; IDs are constrained by company; Sage code is derived from company configuration; an existing CPF reuses its identity/PIN without rewriting credentials.
Task 6 verification: 14 focused resource/manual-search/employee tests passed. The only new build call-site remaining is the worker scheduler, intentionally handled in Task 8.
Task 6: complete.

Task 7 RED: resource-tenancy tests were extended for cross-company export and historical-signature denial.
Task 7 GREEN: payroll normalization derives company from the persisted job, new document paths include company, admin/employee reads and exports are company-scoped, public links resolve company through payroll, and signature PIN validation uses the global identity. Historical links can read signed documents but cannot sign.
Task 7 verification: 13 focused payroll/PDF/signature tests passed; TypeScript has no new Task 7 errors.
Task 7: complete.
